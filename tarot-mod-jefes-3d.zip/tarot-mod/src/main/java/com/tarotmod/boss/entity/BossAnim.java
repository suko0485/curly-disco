package com.tarotmod.boss.entity;

/** GENERADO por gen_bosses.py: IDs y duraciones (ticks) de las animaciones de acción de los jefes. */
public final class BossAnim {
    private BossAnim() {}

    public static final int IDLE = 0;
    public static final int SLAM = 1;
    public static final int CAST = 2;
    public static final int SUMMON = 3;
    public static final int SPECIAL = 4;
    public static final int ENRAGE = 5;

    /** Nombre de clip por ID (el índice 0 es 'sin animación'). */
    public static final String[] NAMES = {"idle", "slam", "cast", "summon", "special", "enrage"};
    /** Duración en ticks por ID. */
    public static final int[] LENGTH = {0, 40, 34, 36, 46, 44};

    public static final int DEATH_LENGTH = 20;
}
