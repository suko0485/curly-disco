package com.tarotmod.boss.entity;

import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** El Juicio Final: coloso alado de armadura dorada con martillo y trompeta. Inmune al fuego y al empuje. */
public class LastJudgementEntity extends TarotBossEntity {
    public LastJudgementEntity(EntityType<? extends LastJudgementEntity> type, World world) { super(type, world); }

    @Override protected double meleeSpeed() { return 0.9; }
    @Override protected float walkRate() { return 0.55f; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_RAVAGER_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_RAVAGER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_RAVAGER_DEATH; }
    @Override protected void playStepSound(BlockPos pos, BlockState state) { playSound(SoundEvents.ENTITY_IRON_GOLEM_STEP, 1.0f, 0.8f); }
}
