package com.tarotmod.boss.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/**
 * Base de los tres jefes del Altar Arcano con modelo propio.
 * El servidor decide qué animación de acción se reproduce ({@link #playAnim}); el cliente la recibe por DataTracker
 * y calcula el avance, la marcha y la mirada de forma local (así el modelo no depende de campos del estado de render de vanilla).
 */
public abstract class TarotBossEntity extends HostileEntity {
    private static final TrackedData<Integer> ANIM = DataTracker.registerData(TarotBossEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ANIM_SEQ = DataTracker.registerData(TarotBossEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> PHASE = DataTracker.registerData(TarotBossEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private int animLeft;                       // solo servidor
    // --- estado local del cliente ---
    private int seenSeq = -1, clientAnim, animElapsed;
    private boolean haveLast;
    private double lastX, lastZ;
    private float walkPos, prevWalkPos, walkAmp, prevWalkAmp, lookYaw, prevLookYaw;

    protected TarotBossEntity(EntityType<? extends TarotBossEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(ANIM, 0);
        builder.add(ANIM_SEQ, 0);
        builder.add(PHASE, 1);
    }

    // ------------------------------------------------------------ API para el BossManager
    /** Reproduce una animación de acción (ver {@link BossAnim}). Mientras dura, el jefe se detiene y encara a su objetivo. */
    public void playAnim(int anim) {
        if (anim <= 0 || anim >= BossAnim.LENGTH.length) return;
        dataTracker.set(ANIM, anim);
        dataTracker.set(ANIM_SEQ, dataTracker.get(ANIM_SEQ) + 1);
        animLeft = BossAnim.LENGTH[anim];
    }

    public int getPhase() { return dataTracker.get(PHASE); }
    public void setPhase(int phase) { dataTracker.set(PHASE, phase); }

    /** Velocidad relativa del ciclo de marcha (jefes enormes pisan más lento). */
    protected float walkRate() { return 1f; }
    protected double meleeSpeed() { return 1.0; }

    // ------------------------------------------------------------ IA
    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, meleeSpeed(), true));
        goalSelector.add(5, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 16f));
        goalSelector.add(7, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) { return false; }

    // ------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (getEntityWorld().isClient()) clientTick(); else serverTick();
    }

    private void serverTick() {
        if (animLeft <= 0) return;
        animLeft--;
        getNavigation().stop();
        getMoveControl().moveTo(getX(), getY(), getZ(), 0);
        LivingEntity target = getTarget();
        if (target != null && target.isAlive()) {
            double dx = target.getX() - getX(), dz = target.getZ() - getZ();
            float want = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90f;
            float y = MathHelper.lerpAngleDegrees(0.4f, getYaw(), want);
            setYaw(y);
            setBodyYaw(y);
            setHeadYaw(y);
        }
    }

    private void clientTick() {
        int seq = dataTracker.get(ANIM_SEQ);
        if (seq != seenSeq) { seenSeq = seq; clientAnim = dataTracker.get(ANIM); animElapsed = 0; }
        else if (animElapsed < 10000) animElapsed++;

        double dx = 0, dz = 0;
        if (haveLast) { dx = getX() - lastX; dz = getZ() - lastZ; }
        haveLast = true; lastX = getX(); lastZ = getZ();
        float target = Math.min((float) Math.sqrt(dx * dx + dz * dz) * 4f, 1f);
        prevWalkPos = walkPos; prevWalkAmp = walkAmp;
        walkAmp += (target - walkAmp) * 0.4f;
        walkPos += walkAmp * walkRate();

        float want = MathHelper.clamp(MathHelper.wrapDegrees(getHeadYaw() - getBodyYaw()), -50f, 50f);
        prevLookYaw = lookYaw;
        lookYaw += (want - lookYaw) * 0.5f;
    }

    // ------------------------------------------------------------ lectura desde el renderer (solo cliente)
    public int clientAnim() { return clientAnim; }
    public float animTime(float tp) { return animElapsed + tp; }
    public float walkPos(float tp) { return MathHelper.lerp(tp, prevWalkPos, walkPos); }
    public float walkAmp(float tp) { return MathHelper.lerp(tp, prevWalkAmp, walkAmp); }
    public float lookYaw(float tp) { return MathHelper.lerp(tp, prevLookYaw, lookYaw); }
    public float lookPitch() { return MathHelper.clamp(getPitch(), -35f, 35f); }
}
