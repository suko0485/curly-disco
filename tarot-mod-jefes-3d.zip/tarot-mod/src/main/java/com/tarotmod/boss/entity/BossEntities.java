package com.tarotmod.boss.entity;

import com.tarotmod.TarotMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

/** Registro de los tipos de entidad de los jefes y de sus atributos base (la vida real la fija el BossManager). */
public final class BossEntities {
    private BossEntities() {}

    public static final EntityType<HierophantEntity> HIEROPHANT = register("hierophant",
            EntityType.Builder.create(HierophantEntity::new, SpawnGroup.MONSTER).dimensions(1.0f, 3.1f).maxTrackingRange(10));
    public static final EntityType<MoonShadowEntity> MOON_SHADOW = register("moon_shadow",
            EntityType.Builder.create(MoonShadowEntity::new, SpawnGroup.MONSTER).dimensions(0.9f, 3.0f).maxTrackingRange(10));
    public static final EntityType<LastJudgementEntity> LAST_JUDGEMENT = register("last_judgement",
            EntityType.Builder.create(LastJudgementEntity::new, SpawnGroup.MONSTER).dimensions(2.0f, 3.9f).maxTrackingRange(12).makeFireImmune());

    private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
        RegistryKey<EntityType<?>> key = RegistryKey.of(RegistryKeys.ENTITY_TYPE, TarotMod.id(name));
        return Registry.register(Registries.ENTITY_TYPE, key, builder.build(key));
    }

    private static DefaultAttributeContainer.Builder attrs(double hp, double speed, double damage, double knockbackResist) {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, hp)
                .add(EntityAttributes.MOVEMENT_SPEED, speed)
                .add(EntityAttributes.ATTACK_DAMAGE, damage)
                .add(EntityAttributes.FOLLOW_RANGE, 40)
                .add(EntityAttributes.KNOCKBACK_RESISTANCE, knockbackResist);
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(HIEROPHANT, attrs(260, 0.25, 8, 0.5));
        FabricDefaultAttributeRegistry.register(MOON_SHADOW, attrs(280, 0.30, 7, 0.3));
        FabricDefaultAttributeRegistry.register(LAST_JUDGEMENT, attrs(600, 0.26, 14, 1.0));
    }
}
