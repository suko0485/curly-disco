package com.tarotmod.boss.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/** El Hierofante Corrompido: sacerdote caído de pasos lentos que domina el altar con su báculo. */
public class HierophantEntity extends TarotBossEntity {
    public HierophantEntity(EntityType<? extends HierophantEntity> type, World world) { super(type, world); }

    @Override protected double meleeSpeed() { return 0.9; }
    @Override protected float walkRate() { return 0.8f; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_EVOKER_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_EVOKER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_EVOKER_DEATH; }
}
