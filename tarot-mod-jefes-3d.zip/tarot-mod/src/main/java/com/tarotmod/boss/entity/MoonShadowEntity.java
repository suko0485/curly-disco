package com.tarotmod.boss.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

/** La Sombra de la Luna: espectro flotante, rápido y esquivo (solo se invoca de noche). */
public class MoonShadowEntity extends TarotBossEntity {
    public MoonShadowEntity(EntityType<? extends MoonShadowEntity> type, World world) { super(type, world); }

    @Override protected double meleeSpeed() { return 1.1; }
    @Override protected float walkRate() { return 0.6f; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_PHANTOM_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_PHANTOM_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_PHANTOM_DEATH; }
}
