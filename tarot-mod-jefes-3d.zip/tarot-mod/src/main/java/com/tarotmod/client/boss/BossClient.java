package com.tarotmod.client.boss;

import com.tarotmod.TarotMod;
import com.tarotmod.boss.entity.BossEntities;
import com.tarotmod.boss.entity.TarotBossEntity;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.entity.EntityType;

/** Registra modelos y renderers de los jefes (se llama desde TarotClient). */
public final class BossClient {
    private BossClient() {}

    public static void init() {
        register(BossEntities.HIEROPHANT, "hierophant", 0.9f);
        register(BossEntities.MOON_SHADOW, "moon_shadow", 0.7f);
        register(BossEntities.LAST_JUDGEMENT, "last_judgement", 1.6f);
    }

    private static <T extends TarotBossEntity> void register(EntityType<T> type, String id, float shadow) {
        BossModelData data = BossModelData.load(id);
        EntityModelLayer layer = new EntityModelLayer(TarotMod.id(id), "main");
        EntityModelLayerRegistry.registerModelLayer(layer, data::createLayer);
        EntityRendererRegistry.register(type, ctx -> new BossRenderer(ctx, data, layer, shadow));
    }
}
