package com.tarotmod.client;

import com.tarotmod.boss.entity.BossAnim;
import com.tarotmod.card.TarotCard;
import com.tarotmod.card.TarotCards;
import com.tarotmod.net.DebugPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Menú de prueba (tecla K, solo en creativo): botones para invocar jefes, lanzar sus animaciones y ataques, dar cartas
 * y objetos, tocar puntos/árbol/colección y disparar profecías y eventos. Las acciones las ejecuta el servidor (debug/DebugActions).
 */
public class DebugScreen extends Screen {
    private static final String[] TABS = {"Jefes", "Cartas", "Destino", "Eventos", "Objetos"};
    private static final String[] LEVELS = {"Normal", "Astral", "Cósmica"};
    private static final int W = 384, H = 236, COLS = 3, BW = 120, BH = 18, PER_PAGE = 15;

    // estado que sobrevive al cerrar/reabrir el menú
    private static int tab = 0, page = 0, level = 0, power = 2;
    private static boolean reversed = false;

    private String last = "Elegí una acción. Las acciones usan al jugador y al jefe más cercano.";
    private int slot = 0;

    public DebugScreen() { super(Text.literal("Menú de prueba · Arcanos")); }

    private int x0() { return this.width / 2 - W / 2; }
    private int y0() { return this.height / 2 - H / 2; }

    @Override public boolean shouldPause() { return false; }

    private void send(String action, String arg, String label) {
        ClientPlayNetworking.send(new DebugPayload(action, arg));
        last = "§a▶ " + label;
    }

    private void btn(String label, Runnable r) {
        int c = slot % COLS, row = slot / COLS;
        slot++;
        this.addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> r.run())
                .dimensions(x0() + 8 + c * (BW + 4), y0() + 50 + row * (BH + 3), BW, BH).build());
    }

    private void act(String label, String action, String arg) { btn(label, () -> send(action, arg, label)); }

    @Override
    protected void init() {
        slot = 0;
        for (int i = 0; i < TABS.length; i++) {
            final int t = i;
            this.addDrawableChild(ButtonWidget.builder(Text.literal((tab == i ? "§e§l" : "") + TABS[i]), b -> { tab = t; page = 0; this.clearAndInit(); })
                    .dimensions(x0() + 8 + i * 75, y0() + 22, 72, 20).build());
        }
        switch (tab) {
            case 0 -> bosses();
            case 1 -> cards();
            case 2 -> destiny();
            case 3 -> events();
            default -> items();
        }
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Cerrar"), b -> this.close())
                .dimensions(x0() + W - 68, y0() + H - 24, 60, 18).build());
    }

    private void bosses() {
        act("§5Invocar Hierofante", "boss_spawn", "0");
        act("§9Invocar Sombra Luna", "boss_spawn", "1");
        act("§6Invocar Juicio Final", "boss_spawn", "2");
        String[] an = {"slam", "cast", "summon", "special", "enrage"};
        String[] anl = {"Golpe", "Bombardeo", "Invocación", "Especial", "Rugido (fase 2)"};
        for (int i = 0; i < an.length; i++) act("Animación: " + anl[i], "boss_anim", String.valueOf(BossAnim.SLAM + i));
        String[] atk = {"Ataque: golpe en área", "Ataque: bombardeo", "Ataque: esbirros", "Ataque: especial f2", "Ataque: anticipado"};
        for (int i = 0; i < atk.length; i++) act(atk[i], "boss_attack", String.valueOf(i));
        act("§eForzar fase 2", "boss_phase2", "");
        act("§aCurar jefe", "boss_heal", "");
        act("§cMatar jefe (drops)", "boss_kill", "");
        act("§7Eliminar jefes", "boss_clear", "");
        act("§8Mini-jefe Presagio", "mini_spawn", "3");
    }

    private void cards() {
        btn("Nivel: §e" + LEVELS[level], () -> { level = (level + 1) % (TarotCard.MAX_LEVEL + 1); this.clearAndInit(); });
        btn("Invertida: " + (reversed ? "§aSí" : "§7No"), () -> { reversed = !reversed; this.clearAndInit(); });
        btn("§6Dar las 22 cartas", () -> send("cards_all", level + ":" + (reversed ? 1 : 0), "22 cartas (" + LEVELS[level] + ")"));
        List<String> ids = new ArrayList<>(TarotCards.ALL.keySet());
        int pages = (ids.size() + PER_PAGE - 1) / PER_PAGE;
        for (int i = page * PER_PAGE; i < Math.min(ids.size(), (page + 1) * PER_PAGE); i++) {
            String id = ids.get(i);
            String name = Text.translatable("item.tarot.card_" + id).getString();
            btn(TarotCards.ALL.get(id).numeral() + " " + name, () -> send("card", id + ":" + level + ":" + (reversed ? 1 : 0), name));
        }
        this.addDrawableChild(ButtonWidget.builder(Text.literal("◀"), b -> { page = (page + pages - 1) % pages; this.clearAndInit(); })
                .dimensions(x0() + 8, y0() + H - 24, 24, 18).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("▶"), b -> { page = (page + 1) % pages; this.clearAndInit(); })
                .dimensions(x0() + 36, y0() + H - 24, 24, 18).build());
    }

    private void destiny() {
        act("+1 Punto de Destino", "points", "1");
        act("+10 Puntos", "points", "10");
        act("+100 Puntos", "points", "100");
        act("Desbloquear todo el árbol", "tree_all", "");
        act("Forjar Cósmica (+1)", "cosmic", "");
        act("Colección completa (22)", "collection_full", "");
        act("Vaciar colección", "collection_clear", "");
        act("§cReiniciar TODO el progreso", "reset_all", "");
        btn("Abrir Árbol del Destino", () -> this.client.setScreen(new DestinyTreeScreen()));
        btn("Abrir Grimorio", () -> this.client.setScreen(new GrimoireScreen()));
    }

    private void events() {
        btn("Poder de la profecía: §e" + power, () -> { power = power % 5 + 1; this.clearAndInit(); });
        act("Cielo Rojo + Grieta", "sky", "");
        act("Acelerar profecías (2 s)", "prophecy_fast", "");
        String[] names = {"§6Fortuna", "§4Peligro", "§dEncuentro"};
        for (int i = 0; i < 3; i++) act("Cumplir ahora: " + names[i], "prophecy_now", i + ":" + power);
        for (int i = 0; i < 3; i++) act("Preparado: " + names[i], "prophecy_prepared", i + ":" + power);
        act("Peligro invertido", "prophecy_reversed", "1:" + power);
        for (int i = 0; i < 3; i++) act("Programar (2-5 min): " + names[i], "prophecy_schedule", String.valueOf(i));
    }

    private void items() {
        String[][] it = {{"Mazo del Destino", "deck"}, {"Sobres x8", "booster"}, {"Polvo Estelar x64", "stardust"}, {"Grimorio", "grimoire"},
                {"Páginas de expansión x3", "pages"}, {"Corazón del Destino", "heart"}, {"Fragmentos x16", "shard"}, {"Lágrimas astrales x4", "tear"},
                {"Coronas rotas x4", "crown"}, {"Altar Arcano", "altar"}, {"Mesa del Tarot", "table"}};
        for (String[] i : it) act(i[0], "item", i[1]);
        act("Kit ritual: Hierofante", "ritual_kit", "0");
        act("Kit ritual: Sombra Luna", "ritual_kit", "1");
        act("Kit ritual: Juicio Final", "ritual_kit", "2");
        act("§aCurarme y saciarme", "heal", "");
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawText(this.textRenderer, Text.literal("§6§l" + this.title.getString()), x0() + 8, y0() + 6, 0xFFFFFFFF, true);
        ctx.drawText(this.textRenderer, Text.literal(last), x0() + 66, y0() + H - 19, 0xFFFFFFFF, true);
    }
}
