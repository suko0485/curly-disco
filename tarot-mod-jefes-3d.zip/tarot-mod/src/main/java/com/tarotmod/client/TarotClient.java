package com.tarotmod.client;

import com.tarotmod.TarotMod;
import com.tarotmod.data.ClientState;
import com.tarotmod.item.GrimoireItem;
import com.tarotmod.net.SyncPayload;
import com.tarotmod.screen.ModScreens;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class TarotClient implements ClientModInitializer {
    public static KeyBinding OPEN_TREE, DEBUG_MENU;

    @Override
    public void onInitializeClient() {
        HandledScreens.register(ModScreens.TABLE, TarotTableScreen::new);
        com.tarotmod.client.boss.BossClient.init();   // modelos 3D animados de los jefes

        // Tecla Z (configurable en Controles -> "Arcanos: Tarot")
        KeyBinding.Category category = KeyBinding.Category.create(TarotMod.id("main"));
        OPEN_TREE = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tarot.open_tree", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, category));
        // Menú de prueba (tecla K): jefes, cartas, destino, profecías y objetos. Solo funciona en creativo.
        DEBUG_MENU = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tarot.debug_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (DEBUG_MENU.wasPressed()) {
                if (mc.player == null || mc.currentScreen != null) continue;
                if (mc.player.isCreative()) mc.setScreen(new DebugScreen());
                else mc.player.sendMessage(net.minecraft.text.Text.literal("§8[Prueba] §7El menú de prueba solo funciona en modo creativo."), true);
            }
            while (OPEN_TREE.wasPressed()) {
                if (mc.player != null && mc.currentScreen == null) mc.setScreen(new DestinyTreeScreen());
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, context) -> ClientState.apply(payload.data()));

        ClientPlayNetworking.registerGlobalReceiver(com.tarotmod.net.SkyPayload.ID, (payload, context) -> SkyOverlay.trigger(payload.ticks()));
        // Capa de HUD (API nueva de Fabric: HudElementRegistry) para el velo rojo
        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.attachElementBefore(
                net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.CHAT, TarotMod.id("sky_overlay"),
                (ctx, tickCounter) -> SkyOverlay.render(ctx));

        GrimoireItem.CLIENT_OPEN = () -> MinecraftClient.getInstance().setScreen(new GrimoireScreen());
    }
}
