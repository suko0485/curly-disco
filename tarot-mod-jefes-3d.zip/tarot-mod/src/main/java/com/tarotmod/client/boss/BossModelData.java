package com.tarotmod.client.boss;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tarotmod.boss.entity.BossAnim;
import com.tarotmod.TarotMod;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Modelo de un jefe cargado desde /tarot_boss/&lt;id&gt;.json (lo genera gen_bosses.py).
 * Posiciones en píxeles de modelo con la convención de Minecraft; rotaciones en grados.
 */
public final class BossModelData {
    public static final int X = 0, Y = 1, Z = 2, RX = 3, RY = 4, RZ = 5;

    public record Box(int u, int v, float x, float y, float z, int dx, int dy, int dz) {}
    public record Walk(int ch, float amp, float phase, float bias) {}
    public static final class Part {
        String name, parent;
        float ox, oy, oz, rx, ry, rz;
        Box[] boxes;
        boolean p2, look;
        float spinY, spinZ;
        Walk[] walk;
    }
    public static final class Track { int part, ch; float[] t, v; int[] e; }
    public static final class Clip { int len; boolean loop; Track[] tracks = new Track[0]; }

    public final String id;
    public final Identifier texture;
    public final int texW, texH;
    final Part[] parts;
    final Map<String, Integer> index = new HashMap<>();
    final Clip idle, death;
    final Clip[] actions;   // indexado por BossAnim (0 = null)

    private BossModelData(String id, JsonObject o) {
        this.id = id;
        this.texture = Identifier.of(TarotMod.MOD_ID, o.get("texture").getAsString());
        this.texW = o.get("tex_w").getAsInt();
        this.texH = o.get("tex_h").getAsInt();
        JsonArray ps = o.getAsJsonArray("parts");
        parts = new Part[ps.size()];
        for (int i = 0; i < parts.length; i++) {
            JsonObject j = ps.get(i).getAsJsonObject();
            Part p = new Part();
            p.name = j.get("name").getAsString();
            p.parent = j.get("parent").isJsonNull() ? null : j.get("parent").getAsString();
            JsonArray oo = j.getAsJsonArray("o"), rr = j.getAsJsonArray("r");
            p.ox = oo.get(0).getAsFloat(); p.oy = oo.get(1).getAsFloat(); p.oz = oo.get(2).getAsFloat();
            p.rx = (float) Math.toRadians(rr.get(0).getAsFloat());
            p.ry = (float) Math.toRadians(rr.get(1).getAsFloat());
            p.rz = (float) Math.toRadians(rr.get(2).getAsFloat());
            JsonArray bs = j.getAsJsonArray("boxes");
            p.boxes = new Box[bs.size()];
            for (int k = 0; k < p.boxes.length; k++) {
                JsonObject b = bs.get(k).getAsJsonObject();
                JsonArray uv = b.getAsJsonArray("uv"), pp = b.getAsJsonArray("p"), s = b.getAsJsonArray("s");
                p.boxes[k] = new Box(uv.get(0).getAsInt(), uv.get(1).getAsInt(), pp.get(0).getAsFloat(), pp.get(1).getAsFloat(), pp.get(2).getAsFloat(),
                        s.get(0).getAsInt(), s.get(1).getAsInt(), s.get(2).getAsInt());
            }
            p.p2 = j.get("p2").getAsBoolean();
            p.look = j.get("look").getAsBoolean();
            JsonArray sp = j.getAsJsonArray("spin");
            p.spinY = sp.get(0).getAsFloat(); p.spinZ = sp.get(1).getAsFloat();
            JsonArray ws = j.getAsJsonArray("walk");
            p.walk = new Walk[ws.size()];
            for (int k = 0; k < p.walk.length; k++) {
                JsonArray w = ws.get(k).getAsJsonArray();
                p.walk[k] = new Walk(channel(w.get(0).getAsString()), w.get(1).getAsFloat(), w.get(2).getAsFloat(), w.get(3).getAsFloat());
            }
            parts[i] = p;
            index.put(p.name, i);
        }
        JsonObject cs = o.getAsJsonObject("clips");
        idle = clip(cs.getAsJsonObject("idle"));
        death = clip(cs.getAsJsonObject("death"));
        actions = new Clip[BossAnim.NAMES.length];
        for (int a = 1; a < actions.length; a++) actions[a] = clip(cs.getAsJsonObject(BossAnim.NAMES[a]));
    }

    private static int channel(String s) {
        return switch (s) { case "x" -> X; case "y" -> Y; case "z" -> Z; case "rx" -> RX; case "ry" -> RY; default -> RZ; };
    }

    private Clip clip(JsonObject j) {
        Clip c = new Clip();
        c.len = j.get("len").getAsInt();
        c.loop = j.get("loop").getAsBoolean();
        java.util.List<Track> list = new java.util.ArrayList<>();
        for (Map.Entry<String, JsonElement> pe : j.getAsJsonObject("tracks").entrySet()) {
            Integer pi = index.get(pe.getKey());
            if (pi == null) continue;
            for (Map.Entry<String, JsonElement> ce : pe.getValue().getAsJsonObject().entrySet()) {
                JsonArray keys = ce.getValue().getAsJsonArray();
                Track t = new Track();
                t.part = pi; t.ch = channel(ce.getKey());
                t.t = new float[keys.size()]; t.v = new float[keys.size()]; t.e = new int[keys.size()];
                for (int k = 0; k < keys.size(); k++) {
                    JsonArray key = keys.get(k).getAsJsonArray();
                    t.t[k] = key.get(0).getAsFloat();
                    t.v[k] = key.get(1).getAsFloat();
                    t.e[k] = switch (key.get(2).getAsString()) { case "l" -> 1; case "in" -> 2; case "out" -> 3; default -> 0; };
                }
                list.add(t);
            }
        }
        c.tracks = list.toArray(new Track[0]);
        return c;
    }

    public static BossModelData load(String id) {
        try (InputStream in = BossModelData.class.getResourceAsStream("/tarot_boss/" + id + ".json")) {
            if (in == null) throw new IllegalStateException("Falta /tarot_boss/" + id + ".json");
            return new BossModelData(id, JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject());
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo leer el modelo del jefe " + id, e);
        }
    }

    /** Capa de modelo (geometría + tamaño de textura). */
    public TexturedModelData createLayer() {
        ModelData md = new ModelData();
        ModelPartData root = md.getRoot();
        Map<String, ModelPartData> map = new HashMap<>();
        for (Part p : parts) {
            ModelPartBuilder b = ModelPartBuilder.create();
            for (Box x : p.boxes) b.uv(x.u(), x.v()).cuboid(x.x(), x.y(), x.z(), x.dx(), x.dy(), x.dz());
            ModelPartData parent = p.parent == null ? root : map.get(p.parent);
            map.put(p.name, parent.addChild(p.name, b, ModelTransform.of(p.ox, p.oy, p.oz, p.rx, p.ry, p.rz)));
        }
        return TexturedModelData.of(md, texW, texH);
    }
}
