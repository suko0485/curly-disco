package com.tarotmod.client.boss;

import net.minecraft.client.render.entity.state.LivingEntityRenderState;

/** Datos de animación de un jefe, copiados de la entidad en cada fotograma. */
public class BossRenderState extends LivingEntityRenderState {
    public int anim;          // ID de BossAnim (0 = ninguna)
    public float animTime;    // ticks desde que empezó la animación de acción
    public float time;        // edad + parcial: reloj de las animaciones de bucle
    public float walkPos, walkAmp;
    public float lookYaw, lookPitch;   // grados
    public float death = -1;  // ticks de muerte (-1 = vivo)
    public int phase = 1;
}
