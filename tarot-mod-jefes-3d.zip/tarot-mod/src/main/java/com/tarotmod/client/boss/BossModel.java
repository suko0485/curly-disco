package com.tarotmod.client.boss;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.render.entity.model.EntityModel;

/**
 * Modelo genérico de jefe: reposo + clip 'idle' (bucle) + clip de acción + marcha + giros + mirada + clip de muerte.
 * Todo es aditivo sobre la pose de reposo y se calcula solo desde el estado de render (el modelo se comparte entre entidades).
 * La lógica es idéntica a bosslib.pose() de gen_bosses.py (lo que se ve en previews/ es lo que se ve en el juego).
 */
public class BossModel extends EntityModel<BossRenderState> {
    private static final float DEG = (float) (Math.PI / 180.0);

    private final BossModelData data;
    private final ModelPart[] parts;

    public BossModel(ModelPart root, BossModelData data) {
        super(root);
        this.data = data;
        this.parts = new ModelPart[data.parts.length];
        for (int i = 0; i < parts.length; i++) {
            BossModelData.Part p = data.parts[i];
            parts[i] = p.parent == null ? root.getChild(p.name) : parts[data.index.get(p.parent)].getChild(p.name);
        }
    }

    private static float ease(int kind, float u) {
        return switch (kind) {
            case 1 -> u;
            case 2 -> u * u * u;
            case 3 -> 1 - (1 - u) * (1 - u) * (1 - u);
            default -> u * u * (3 - 2 * u);
        };
    }

    private static float sample(BossModelData.Track tr, float t) {
        float[] ts = tr.t, vs = tr.v;
        int n = ts.length;
        if (t <= ts[0]) return vs[0];
        if (t >= ts[n - 1]) return vs[n - 1];
        for (int i = 0; i < n - 1; i++) {
            if (t <= ts[i + 1]) {
                float u = (t - ts[i]) / Math.max(1e-6f, ts[i + 1] - ts[i]);
                return vs[i] + (vs[i + 1] - vs[i]) * ease(tr.e[i + 1], u);
            }
        }
        return vs[n - 1];
    }

    private static void apply(BossModelData.Clip c, float t, float[] pose) {
        for (BossModelData.Track tr : c.tracks) {
            float v = sample(tr, t);
            pose[tr.part * 6 + tr.ch] += tr.ch >= BossModelData.RX ? v * DEG : v;
        }
    }

    @Override
    public void setAngles(BossRenderState s) {
        super.setAngles(s);
        int n = parts.length;
        float[] pose = new float[n * 6];
        for (int i = 0; i < n; i++) {
            BossModelData.Part p = data.parts[i];
            pose[i * 6] = p.ox; pose[i * 6 + 1] = p.oy; pose[i * 6 + 2] = p.oz;
            pose[i * 6 + 3] = p.rx; pose[i * 6 + 4] = p.ry; pose[i * 6 + 5] = p.rz;
        }
        apply(data.idle, s.time % data.idle.len, pose);
        if (s.anim > 0 && s.anim < data.actions.length && s.animTime < data.actions[s.anim].len) apply(data.actions[s.anim], s.animTime, pose);

        float f = s.walkPos * 0.6662f;
        for (int i = 0; i < n; i++) {
            BossModelData.Part p = data.parts[i];
            for (BossModelData.Walk w : p.walk) {
                float v = (w.amp() * (float) Math.sin(f + w.phase()) + w.bias()) * s.walkAmp;
                if (w.ch() == BossModelData.Y) v = -v;
                pose[i * 6 + w.ch()] += w.ch() >= BossModelData.RX ? v * DEG : v;
            }
            pose[i * 6 + 4] += p.spinY * s.time * DEG;
            pose[i * 6 + 5] += p.spinZ * s.time * DEG;
            if (p.look) {
                pose[i * 6 + 4] += s.lookYaw * DEG;
                pose[i * 6 + 3] += s.lookPitch * DEG;
            }
        }
        if (s.death >= 0) apply(data.death, Math.min(s.death, data.death.len), pose);

        for (int i = 0; i < n; i++) {
            parts[i].setTransform(ModelTransform.of(pose[i * 6], pose[i * 6 + 1], pose[i * 6 + 2], pose[i * 6 + 3], pose[i * 6 + 4], pose[i * 6 + 5]));
            parts[i].visible = !(data.parts[i].p2 && s.phase < 2);
        }
    }
}
