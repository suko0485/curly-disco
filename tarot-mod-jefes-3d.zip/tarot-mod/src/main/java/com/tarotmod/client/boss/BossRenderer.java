package com.tarotmod.client.boss;

import com.tarotmod.boss.entity.TarotBossEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

public class BossRenderer extends MobEntityRenderer<TarotBossEntity, BossRenderState, BossModel> {
    private final Identifier texture;

    public BossRenderer(EntityRendererFactory.Context ctx, BossModelData data, EntityModelLayer layer, float shadowRadius) {
        super(ctx, new BossModel(ctx.getPart(layer), data), shadowRadius);
        this.texture = data.texture;
    }

    @Override
    public BossRenderState createRenderState() { return new BossRenderState(); }

    @Override
    public Identifier getTexture(BossRenderState state) { return texture; }

    @Override
    public void updateRenderState(TarotBossEntity e, BossRenderState s, float tickProgress) {
        super.updateRenderState(e, s, tickProgress);
        s.anim = e.clientAnim();
        s.animTime = e.animTime(tickProgress);
        s.time = e.age + tickProgress;
        s.walkPos = e.walkPos(tickProgress);
        s.walkAmp = e.walkAmp(tickProgress);
        s.lookYaw = e.lookYaw(tickProgress);
        s.lookPitch = e.lookPitch();
        s.death = e.deathTime > 0 ? e.deathTime + tickProgress : -1;
        s.phase = e.getPhase();
    }
}
