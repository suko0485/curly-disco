package com.tarotmod.net;

import com.tarotmod.TarotMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Cliente -> servidor: acción del menú de prueba (ver debug/DebugActions). */
public record DebugPayload(String action, String arg) implements CustomPayload {
    public static final CustomPayload.Id<DebugPayload> ID = new CustomPayload.Id<>(TarotMod.id("debug"));
    public static final PacketCodec<RegistryByteBuf, DebugPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, DebugPayload::action, PacketCodecs.STRING, DebugPayload::arg, DebugPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
