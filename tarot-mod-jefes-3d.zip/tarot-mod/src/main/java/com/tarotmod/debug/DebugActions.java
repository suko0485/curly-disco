package com.tarotmod.debug;

import com.tarotmod.boss.BossManager;
import com.tarotmod.boss.entity.BossAnim;
import com.tarotmod.boss.entity.TarotBossEntity;
import com.tarotmod.card.SkyEvent;
import com.tarotmod.card.TarotCards;
import com.tarotmod.data.DestinyManager;
import com.tarotmod.data.Nodes;
import com.tarotmod.data.PlayerData;
import com.tarotmod.item.ModItems;
import com.tarotmod.item.TarotCardItem;
import com.tarotmod.block.ModBlocks;
import com.tarotmod.prophecy.ProphecyManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Acciones del menú de prueba (tecla K). Se ejecutan en el servidor y solo si el jugador está en modo creativo.
 * Cada acción es "nombre" + argumento de texto; ver client/DebugScreen para la lista de botones.
 */
public final class DebugActions {
    private DebugActions() {}

    private static void msg(ServerPlayerEntity p, String s) { p.sendMessage(Text.literal("§8[Prueba] §7" + s), true); }
    private static void give(ServerPlayerEntity p, Item item, int n) { p.getInventory().offerOrDrop(new ItemStack(item, n)); }
    private static void giveCard(ServerPlayerEntity p, String id, int level, boolean rev) {
        TarotCardItem item = ModItems.CARDS.get(id);
        if (item == null) return;
        p.getInventory().offerOrDrop(TarotCardItem.asReversed(TarotCardItem.withLevel(new ItemStack(item), level), rev));
    }

    private static TarotBossEntity nearestBoss(ServerWorld w, ServerPlayerEntity p) {
        List<TarotBossEntity> l = w.getEntitiesByClass(TarotBossEntity.class, p.getBoundingBox().expand(96), TarotBossEntity::isAlive);
        TarotBossEntity best = null; double bd = Double.MAX_VALUE;
        for (TarotBossEntity e : l) { double d = e.squaredDistanceTo(p); if (d < bd) { bd = d; best = e; } }
        return best;
    }

    private static int num(String s, int def) { try { return Integer.parseInt(s); } catch (Exception e) { return def; } }

    public static void run(ServerPlayerEntity p, String action, String arg) {
        if (!p.isCreative()) { msg(p, "§cEl menú de prueba solo funciona en modo creativo."); return; }
        ServerWorld w = (ServerWorld) p.getEntityWorld();
        PlayerData d = DestinyManager.get(p);
        switch (action) {
            // ---------------- jefes
            case "boss_spawn" -> { BossManager.debugSpawn(w, p, num(arg, 0)); msg(p, "Jefe invocado."); }
            case "boss_anim" -> {
                TarotBossEntity b = nearestBoss(w, p);
                int id = num(arg, 1);
                if (b == null) msg(p, "§cNo hay un jefe cerca (96 bloques)."); else { b.playAnim(id); msg(p, "Animación: " + BossAnim.NAMES[id]); }
            }
            case "boss_attack" -> msg(p, BossManager.debugAttack(w, p, num(arg, 0)) ? "Ataque lanzado." : "§cNo hay un jefe activo cerca.");
            case "boss_phase2" -> {
                TarotBossEntity b = nearestBoss(w, p);
                if (b == null) msg(p, "§cNo hay un jefe cerca."); else { b.setHealth(b.getMaxHealth() * 0.49f); msg(p, "Vida al 49%: entra en fase 2."); }
            }
            case "boss_heal" -> {
                TarotBossEntity b = nearestBoss(w, p);
                if (b == null) msg(p, "§cNo hay un jefe cerca."); else { b.setHealth(b.getMaxHealth()); msg(p, "Jefe curado."); }
            }
            case "boss_kill" -> {
                TarotBossEntity b = nearestBoss(w, p);
                if (b == null) msg(p, "§cNo hay un jefe cerca."); else { b.damage(w, w.getDamageSources().genericKill(), 1.0E6f); msg(p, "Jefe derrotado (con drops)."); }
            }
            case "boss_clear" -> {
                int n = 0;
                for (TarotBossEntity e : w.getEntitiesByClass(TarotBossEntity.class, p.getBoundingBox().expand(128), x -> true)) { e.discard(); n++; }
                msg(p, n + " jefe(s) eliminados sin drops.");
            }
            case "mini_spawn" -> {
                Vec3d look = p.getRotationVector();
                BossManager.spawnMini(w, p, new Vec3d(p.getX() + look.x * 6, p.getY(), p.getZ() + look.z * 6), num(arg, 3));
                msg(p, "Mini-jefe invocado.");
            }
            // ---------------- cartas
            case "card" -> { // id:nivel:invertida
                String[] a = arg.split(":");
                giveCard(p, a[0], num(a.length > 1 ? a[1] : "0", 0), a.length > 2 && a[2].equals("1"));
                msg(p, "Carta entregada: " + a[0]);
            }
            case "cards_all" -> { // nivel:invertida
                String[] a = arg.split(":");
                for (String id : TarotCards.ALL.keySet()) giveCard(p, id, num(a[0], 0), a.length > 1 && a[1].equals("1"));
                msg(p, "22 cartas entregadas.");
            }
            case "collection_full" -> { d.cards.addAll(TarotCards.ALL.keySet()); DestinyManager.sync(p); msg(p, "Colección completa registrada (sin recompensas)."); }
            case "collection_clear" -> { d.cards.clear(); DestinyManager.sync(p); msg(p, "Colección vaciada."); }
            // ---------------- destino
            case "points" -> { d.points += num(arg, 1); DestinyManager.sync(p); msg(p, "+" + arg + " puntos. Total: " + d.points); }
            case "tree_all" -> { for (Nodes.Node n : Nodes.ALL) d.nodes.add(n.id()); d.cosmic = Math.max(1, d.cosmic); DestinyManager.sync(p); msg(p, "Árbol desbloqueado."); }
            case "cosmic" -> { d.cosmic++; DestinyManager.sync(p); msg(p, "Cósmicas forjadas: " + d.cosmic); }
            case "reset_all" -> { d.points = 0; d.cosmic = 0; d.cards.clear(); d.nodes.clear(); d.prophecies.clear(); DestinyManager.sync(p); msg(p, "Progreso reiniciado."); }
            // ---------------- eventos
            case "prophecy_now" -> { // tipo:poder
                String[] a = arg.split(":");
                ProphecyManager.debugFulfil(w, p, ProphecyManager.Prophecy.values()[num(a[0], 0)], num(a.length > 1 ? a[1] : "1", 1), false, false);
            }
            case "prophecy_prepared" -> {
                String[] a = arg.split(":");
                ProphecyManager.debugFulfil(w, p, ProphecyManager.Prophecy.values()[num(a[0], 0)], num(a.length > 1 ? a[1] : "1", 1), true, false);
            }
            case "prophecy_reversed" -> {
                String[] a = arg.split(":");
                ProphecyManager.debugFulfil(w, p, ProphecyManager.Prophecy.values()[num(a[0], 0)], num(a.length > 1 ? a[1] : "1", 1), false, true);
            }
            case "prophecy_schedule" -> { ProphecyManager.schedule(p, ProphecyManager.Prophecy.values()[num(arg, 0)], 2, -1, false); }
            case "prophecy_fast" -> { for (int[] pr : d.prophecies) pr[1] = Math.min(pr[1], 40); msg(p, d.prophecies.size() + " profecía(s) se cumplen en ~2 s."); }
            case "sky" -> SkyEvent.play(w, p, 200);
            // ---------------- objetos
            case "item" -> {
                switch (arg) {
                    case "deck" -> give(p, ModItems.DESTINY_DECK, 1);
                    case "booster" -> give(p, ModItems.BOOSTER_PACK, 8);
                    case "stardust" -> give(p, ModItems.STARDUST, 64);
                    case "grimoire" -> give(p, ModItems.GRIMOIRE, 1);
                    case "pages" -> give(p, ModItems.EXPANSION_PAGE, 3);
                    case "heart" -> give(p, ModItems.DESTINY_HEART, 1);
                    case "shard" -> give(p, ModItems.DESTINY_SHARD, 16);
                    case "tear" -> give(p, ModItems.ASTRAL_TEAR, 4);
                    case "crown" -> give(p, ModItems.BROKEN_CROWN, 4);
                    case "altar" -> give(p, ModBlocks.ALTAR_ITEM, 1);
                    case "table" -> give(p, ModBlocks.TAROT_TABLE_ITEM, 1);
                    default -> { }
                }
                msg(p, "Entregado: " + arg);
            }
            case "ritual_kit" -> { // 0 Hierofante, 1 Sombra, 2 Juicio
                String[][] kit = {{"tower", "magician", "sun"}, {"star", "fool", "chariot"}, {"wheel", "star", "empress"}};
                int k = num(arg, 0);
                for (String id : kit[k]) giveCard(p, id, 0, false);
                if (k == 2) give(p, ModItems.EXPANSION_PAGE, 3);
                msg(p, "Kit de ritual entregado: ponelo en el Altar Arcano.");
            }
            // ---------------- jugador
            case "heal" -> { p.setHealth(p.getMaxHealth()); p.getHungerManager().setFoodLevel(20); p.clearStatusEffects(); msg(p, "Curado."); }
            case "dust_stack" -> { give(p, ModItems.STARDUST, 64); msg(p, "Polvo estelar x64."); }
            default -> msg(p, "§cAcción desconocida: " + action);
        }
    }
}
